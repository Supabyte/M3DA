Le code peut être testé utilisant le fichier 'test.sce'. 

Plusieurs fonctions supplémentaires (utils.sce) ont été utilisé pour extraire des informations des matrices des paramètres extrinsèques.

Veuillez excuser mon français !
