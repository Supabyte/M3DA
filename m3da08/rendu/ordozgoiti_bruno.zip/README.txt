Ce que l'utilisateur peut faire:
-Créer une courbe Chaikin
-Créer une courbe 4point
-En cliquant le bouton droite on peut créer des points fixes.
-En appuyant sur la touche S on peut subdiviser la courbe.
-En appuyant sur la touche C on peut fermer la courbe.

Il semble y avoir un problème avec l'affichage du 4point lorsqu'on fait des subdivions.

