#include "completenurbs.h"

CompleteNurbs::CompleteNurbs()
{
}

CompleteNurbs::evalBSpline(double){
    Nurbs::
}
