#include "abstractvector.h"

AbstractVector::AbstractVector()
{
}
