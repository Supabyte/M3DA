#include "simplifiednurbs.h"

SimplifiedNurbs::SimplifiedNurbs()
{
}
