#ifndef SIMPLIFIEDNURBS_H
#define SIMPLIFIEDNURBS_H

class SimplifiedNurbs : public Nurbs
{
public:
    SimplifiedNurbs();
};

#endif // SIMPLIFIEDNURBS_H
